<?php

namespace App\Http\Controllers;

use App\Models\Property;
use Illuminate\Http\Request;

class PropertyApiController extends Controller
{
    protected $specificColumnsRelationships = [

    ];
    // 1. Get all properties
    public function index(Request $request)
    {
        $perPage = $request->input('per_page', 10);
        $properties = Property::with($this->specificColumnsRelationships)->paginate($perPage);

        return response()->json($properties, 200);
    }

    // 2. Get a specific property by ID
    public function show($id)
    {
        $property = Property::with($this->specificColumnsRelationships)->find($id);

        if (!$property) {
            return response()->json(['error' => 'Property not found'], 404);
        }

        return response()->json($property, 200);
    }
    // 3. Get a specific Number of properties
    public function getLimitedProperties(Request $request)
    {

        $limit = $request->input('limit', 12);

        $properties = Property::with($this->specificColumnsRelationships)->limit($limit)->get();

        return response()->json($properties, 200);
    }
    // 4. Get a Price Sorted properties
    public function getPropertiesSortedByPrice(Request $request)
    {
        $sortDirection = $request->input('sort', 'asc');
        if (!in_array($sortDirection, ['asc', 'desc'])) {
            return response()->json(['error' => 'Invalid sort direction'], 400);
        }

        $properties = Property::with($this->specificColumnsRelationships)->orderBy('price', $sortDirection)->get();

        return response()->json($properties, 200);
    }

    //5.Get a Product through search query
    public function search(Request $request)
    {
        // Get the search keyword from the query parameter
        $keyword = $request->input('keyword');

        // If no keyword is provided, return an error
        if (!$keyword) {
            return response()->json(['error' => 'No search keyword provided'], 400);
        }

        // Perform the search
        $properties = Property::with($this->specificColumnsRelationships)->where('location_detail', 'LIKE', "%{$keyword}%")
            ->orWhere('type', 'LIKE', "%{$keyword}%")
            ->orWhere('town', 'LIKE', "%{$keyword}%")
            ->orWhere('province', 'LIKE', "%{$keyword}%")
            ->get();

        // Return the results
        return response()->json($properties, 200);
    }
    //6.Get a distinct types
    public function getDistinctTypes()
    {

        $types = Property::select('type')->distinct()->pluck('type');

        if ($types->isEmpty()) {
            return response()->json(['message' => 'No property types found'], 404);
        }

        return response()->json($types, 200);
    }

    //7. Get properties by a specific type.

    public function getByType(string $type)
    {
        $properties = Property::searchByType($type)->with($this->specificColumnsRelationships)->get();
        if ($properties->isEmpty()) {
            return response()->json(['message' => 'No properties found for the specified type'], 404);
        }

        return response()->json($properties, 200);}



        //68.Get Properties Currency
    public function getpropertycurrency()
    {

        $types = Property::select('currency')->distinct()->pluck('currency');

        if ($types->isEmpty()) {
            return response()->json(['message' => 'No property currency found'], 404);
        }

        return response()->json($types, 200);
    }

}

