@extends('layouts.app')

@section('title', 'Permissions')
@section('css')
<style>
    @import url(https://fonts.googleapis.com/css?family=Numans);

    body {
        font-family: 'Numans', sans-serif;
    }



    .checkdiv {
        position: relative;
        padding: 4px 8px;
        border-radius: 40px;
        margin-bottom: 4px;
        min-height: 30px;
        padding-left: 40px;
        display: flex;
        align-items: center;
    }

    .checkdiv:last-child {
        margin-bottom: 0px;
    }

    .checkdiv span {
        position: relative;
        vertical-align: middle;
        line-height: normal;
    }

    .le-checkbox {
        appearance: none;
        position: absolute;
        top: 50%;
        left: 5px;
        transform: translateY(-50%);
        background-color: #F44336;
        width: 30px;
        height: 30px;
        border-radius: 40px;
        margin: 0px;
        outline: none;
        transition: background-color .5s;
    }

    .le-checkbox:before {
        content: '';
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%) rotate(45deg);
        background-color: #ffffff;
        width: 20px;
        height: 5px;
        border-radius: 40px;
        transition: all .5s;
    }

    .le-checkbox:after {
        content: '';
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%) rotate(-45deg);
        background-color: #ffffff;
        width: 20px;
        height: 5px;
        border-radius: 40px;
        transition: all .5s;
    }

    .le-checkbox:checked {
        background-color: #4CAF50;
    }

    .le-checkbox:checked:before {
        content: '';
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%) translate(-4px, 3px) rotate(45deg);
        background-color: #ffffff;
        width: 12px;
        height: 5px;
        border-radius: 40px;
    }

    .le-checkbox:checked:after {
        content: '';
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%) translate(3px, 2px) rotate(-45deg);
        background-color: #ffffff;
        width: 16px;
        height: 5px;
        border-radius: 40px;
    }
</style>
@endsection
@section("content")
<div class="row">
    <div class="col-sm-12">
        <div class="page-title-box">
            <div class="float-right">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Dashboard</a></li>
                    <li class="breadcrumb-item active">Manage Permission</li>
                </ol>
            </div>
            <h4 class="page-title">Manage Permissions</h4>
        </div><!--end page-title-box-->
    </div><!--end col-->
</div>
<!-- end page title end breadcrumb -->
<div class="row">
    <div class=" m-2 col-lg-3">
        <div class="card" >
            <div class="card-body">
                <div class="row">
                    <div class="col-4 align-self-center">
                        <div class="icon-info">
                            <i data-feather="smile" class="align-self-center icon-lg icon-dual-warning"></i>
                        </div>
                    </div>
                    <div class="col-8 align-self-center text-right">
                        <div class="ml-2">
                            <p class="mb-1 text-muted">Total Permissions</p>
                            <input class=" h3 mt-0 mb-1 font-weight-semibold text-center" name="total_sales" id="total_sales" value="{{totalPermissions()}}" readonly style="background: transparent; border: none;margin-left: -30px">
                        </div>
                    </div>
                </div>
            </div><!--end card-body-->
        </div><!--end card-->
    </div>
</div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">

                    <div class="card-body">

                        <div class="container">
                            <table class="table table-borderless mb-0" id="managePerm">
                                <thead>
                                <tr>
                                    <th>Roles / Permissions</th>
                                    @foreach ($roles as $item)
                                    {{-- {{ dd(auth()->user()->has )}} --}}
                                    @if( $item->name == 'admin')
                                     @continue
                                    @endif
                                        <td>{{ $item->name }}</td>
                                    @endforeach
                                </tr>
                                </thead>
                                <tbody>
                                @foreach ($permissions as $perm)
                                    <tr>
                                        <td>{{ $perm->name }}</td>
                                        @foreach ($roles as $rol)
                                            @if( $rol->name == 'admin')
                                             @continue
                                            @endif
                                            <td>
                                                <fieldset>
                                                    <div class="vs-checkbox-con vs-checkbox-success">
                                                        <div class="holder">
                                                            <div class="checkdiv grey400">
                                                                <input type="checkbox" class="le-checkbox permissions" id="chkbox" value="1" data-role="{{ $rol->id }}" data-permission="{{ $perm->id }}" {{ checkRolePerm($rol->id, $perm->id) }} />
                                                            </div>
                                                        </div>
                                                        {{-- <input type="checkbox" value="1" data-role="{{ $rol->id }}" data-permission="{{ $perm->id }}" {{ checkRolePerm($rol->id, $perm->id) }} class="permissions"> --}}
                                                        {{-- <span class="vs-checkbox">
                                                            <span class="vs-checkbox--check">
                                                                <i class="vs-icon feather icon-check"></i>
                                                            </span>
                                                        </span> --}}
                                                    </div>
                                                </fieldset>
                                            </td>
                                        @endforeach
                                    </tr>
                                @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('js')
    <script>
        $(document).on("change", ".permissions", function() {
            let elm = $(this);
            $.ajax({
                type: "GET",
                url: "{{ route('permission.manage') }}",
                data: {
                    role : elm.data('role'),
                    permission : elm.data('permission'),
                },
                success: function (response) {
                    if (response.status == 200) {
                        toastr.success(response.message)
                    }
                }
            });
        });

        var table = $('#datatables').DataTable({
            "sort": false,
            "ordering": false,
            "pagingType": "full_numbers",
            "processing": true,
            "serverSide": true,
            "lengthMenu": [
                [10, 25, 50, -1],
                [10, 25, 50, "All"]
            ],
            responsive: true,
            orderable: true,
            searchable: true,
            language: {
                search: "_INPUT_",
                searchPlaceholder: "Search records",
            }
        });
    </script>
@endsection
